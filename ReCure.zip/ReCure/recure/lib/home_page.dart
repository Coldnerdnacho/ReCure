import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  // Function to make phone calls
  Future<void> _callNumber(String number) async {
    final Uri callUri = Uri(scheme: 'tel', path: number);
    try {
      await launchUrl(callUri, mode: LaunchMode.externalApplication);
    } catch (e) {
      debugPrint('Could not launch $number: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDB230), // Orange/yellow background
      appBar: AppBar(
        backgroundColor: const Color(0xFFFDB230),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.copy, color: Colors.black),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert, color: Colors.black),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          // Top row
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: _buildMenuCard(
                    context,
                    assetPath: "assets/medicines.png",
                    label: "MEDICINES",
                    route: '/medicine',
                  ),
                ),
                Container(width: 2, color: Colors.black),
                Expanded(
                  child: _buildMenuCard(
                    context,
                    assetPath: "assets/excercise.png",
                    label: "EXERCISE",
                    route: '/exercise',
                  ),
                ),
              ],
            ),
          ),
          Container(height: 2, color: Colors.black),
          // Middle row
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: _buildMenuCard(
                    context,
                    assetPath: "assets/meals.png",
                    label: "MEALS",
                    route: '/meals',
                  ),
                ),
                Container(width: 2, color: Colors.black),
                Expanded(
                  child: _buildMenuCard(
                    context,
                    assetPath: "assets/appointments.png",
                    label: "APPOINTMENTS",
                    route: '/appointments',
                  ),
                ),
              ],
            ),
          ),
          Container(height: 2, color: Colors.black),
          // Bottom row
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: _buildMenuCard(
                    context,
                    assetPath: "assets/call_doc.png",
                    label: "CALL DOCTOR",
                    onTap: () => _callNumber('1234567890'),
                    bgColor: const Color(0xFFFDB230),
                    textColor: Colors.black,
                  ),
                ),
                Container(width: 2, color: Colors.black),
                Expanded(
                  child: _buildMenuCard(
                    context,
                    assetPath: "assets/call_ambulance.png",
                    label: "CALL\nAMBULANCE",
                    onTap: () => _callNumber('108'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuCard(
    BuildContext context, {
    required String assetPath,
    required String label,
    String? route,
    Function()? onTap,
    Color bgColor = const Color(0xFFFDB230),
    Color textColor = Colors.black,
  }) {
    return GestureDetector(
      onTap: onTap ?? () => Navigator.pushNamed(context, route!),
      child: Container(
        decoration: BoxDecoration(
          color: bgColor,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              assetPath,
              width: 90,
              height: 90,
              fit: BoxFit.contain,
              errorBuilder: (context, error, stackTrace) {
                return Icon(
                  Icons.image_not_supported,
                  size: 90,
                  color: textColor,
                );
              },
            ),
            const SizedBox(height: 12),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: textColor,
                fontWeight: FontWeight.w900,
                fontSize: 13,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}