import 'package:flutter/material.dart';
import 'home_page.dart'; // Make sure this matches your HomePage file name

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ReCure - Post-Discharge Support',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.amber,
        useMaterial3: true,
      ),
      home: const HomePage(),
      routes: {
        '/medicine': (context) => const PlaceholderPage(title: 'Medicines'),
        '/exercise': (context) => const PlaceholderPage(title: 'Exercise'),
        '/meals': (context) => const PlaceholderPage(title: 'Meals'),
        '/appointments': (context) => const PlaceholderPage(title: 'Appointments'),
      },
    );
  }
}

// Temporary placeholder page for routes
class PlaceholderPage extends StatelessWidget {
  final String title;
  
  const PlaceholderPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Text(
          '$title Page\nComing Soon!',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}