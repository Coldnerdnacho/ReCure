package com.example.recure

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
